(function (i, s, o, g, r, a, m) {
  i['GoogleAnalyticsObject'] = r
  i[r] = i[r] || function () {
    (i[r].q = i[r].q || []).push(arguments)
  }, i[r].l = 1 * new Date()
  a = s.createElement(o)
  m = s.getElementsByTagName(o)[0]
  a.async = 1
  a.src = g
  m.parentNode.insertBefore(a, m)
})(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga')
window.ga('create', 'UA-124507512-38', 'auto')
window.ga('send', 'pageview')

window.onload = function () {
  var script = document.createElement('script')
  script.setAttribute('async', 'async')
  script.src = 'https://www.googletagmanager.com/gtag/js?id=UA-124507512-36'
  document.querySelector('body').appendChild(script)
}

window.dataLayer = window.dataLayer || []
function gtag () {
  window.dataLayer.push(arguments)
}
gtag('js', new Date())
gtag('config', 'UA-124507512-36')
